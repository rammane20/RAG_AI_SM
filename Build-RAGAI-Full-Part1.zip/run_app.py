"""
AI-SM Web Application Launcher
Author: Suyash Mane (suyashmane97@gmail.com)
Project: AI-SM
"""

import mimetypes
import sys
from pathlib import Path

# Ensure correct MIME types for JavaScript on Windows
mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("application/javascript", ".mjs")

if __name__ == "__main__":
    import streamlit.web.cli as stcli

    app_path = str(Path(__file__).resolve().parent / "src" / "ai_sm" / "streamlit_app.py")
    sys.argv = ["streamlit", "run", app_path, "--server.port", "8501"]
    sys.exit(stcli.main())

