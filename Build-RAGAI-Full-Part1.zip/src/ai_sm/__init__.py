"""
AI-SM: Advanced Intelligence & Retrieval Augmented Generation System.
Developed and Maintained by Suyash Mane (suyashmane97@gmail.com).
"""

__version__ = "3.1.0"
__author__ = "Suyash Mane"

from .hybrid_rag import HybridRAGEngine, DocumentChunk
from .corrective_rag import CorrectiveRAG, EvaluationResult

__all__ = [
    "HybridRAGEngine",
    "DocumentChunk",
    "CorrectiveRAG",
    "EvaluationResult",
    "__version__",
    "__author__",
]

