"""
Interactive CLI Application for AI-SM RAG System
Author: Suyash Mane (suyashmane97@gmail.com)
Project: AI-SM
"""

import os
import sys
import re
import argparse
from typing import Optional
from pathlib import Path

# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Add project root to sys.path
CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.ai_sm.hybrid_rag import HybridRAGEngine
from src.ai_sm.corrective_rag import CorrectiveRAG


GREETINGS_PATTERN = re.compile(
    r"^\s*(hi|hello|hey|greetings|good morning|good afternoon|good evening|who are you|what can you do|help|thanks|thank you|about)\b",
    re.IGNORECASE,
)


def check_conversational_intent(query: str) -> Optional[str]:
    """Checks if the user input is a greeting or general meta-question."""
    q_clean = query.strip().lower()
    
    if GREETINGS_PATTERN.match(q_clean) or q_clean in ["hi", "hello", "hey", "help", "who are you"]:
        return (
            "Hello! I am AI-SM, an intelligent Retrieval-Augmented Generation (RAG) assistant "
            "developed by Suyash Mane (suyashmane97@gmail.com).\n\n"
            "I am connected to your knowledge base and can answer questions about:\n"
            "  * AI Agent Architectures (ReAct loop, memory buffers, multi-agent systems)\n"
            "  * Vector Databases (ChromaDB, Pinecone, FAISS, Qdrant, Weaviate comparison)\n"
            "  * RAG Best Practices (Chunking strategies, embedding models, evaluation metrics)\n"
            "  * LLM Engineering (Context window optimization, prompt caching, token reduction)\n\n"
            "Try asking: 'What is the ReAct loop?' or 'Which vector database is best for local development?'"
        )
    return None


def generate_extractive_answer(query: str, context: str) -> str:
    """
    Synthesizes a grounded factual summary from the retrieved context.
    If an OpenAI or DeepSeek API key is set in the environment, it calls the LLM;
    otherwise it performs robust in-context extraction and structuring.
    """
    # 1. Check for conversational greetings
    greeting = check_conversational_intent(query)
    if greeting:
        return greeting

    # 2. If no context found
    if not context or not context.strip():
        return (
            "I couldn't find relevant information in the currently indexed knowledge base (`data/`) "
            "to answer your question directly. \n\n"
            "💡 **Suggested queries to try:**\n"
            "- *What is the ReAct framework in AI agents?*\n"
            "- *Compare ChromaDB and Pinecone for vector search.*\n"
            "- *What chunking strategy is recommended for legal or academic texts?*\n"
            "- *How do I avoid the 'Lost in the Middle' problem with LLMs?*"
        )

    # 3. If API Key is present, use LLM
    api_key = os.getenv("OPENAI_API_KEY") or os.getenv("DEEPSEEK_API_KEY")
    if api_key and not api_key.startswith("sk-fff"):
        try:
            import requests
            headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
            url = "https://api.openai.com/v1/chat/completions" if os.getenv("OPENAI_API_KEY") else "https://api.deepseek.com/chat/completions"
            model = "gpt-4o-mini" if os.getenv("OPENAI_API_KEY") else "deepseek-chat"
            
            payload = {
                "model": model,
                "messages": [
                    {
                        "role": "system",
                        "content": "You are AI-SM, an advanced AI Assistant built by Suyash Mane (suyashmane97@gmail.com). Answer the question accurately using the provided context. Cite source files.",
                    },
                    {
                        "role": "user",
                        "content": f"Context:\n{context}\n\nQuestion: {query}",
                    },
                ],
                "temperature": 0.2,
            }
            resp = requests.post(url, headers=headers, json=payload, timeout=20)
            if resp.status_code == 200:
                return resp.json()["choices"][0]["message"]["content"]
        except Exception:
            pass

    # 4. Local High-Quality Extractive Synthesis
    cleaned_paragraphs = []
    for block in context.split("---"):
        block = block.strip()
        if not block:
            continue
        # Remove source header if present
        block_clean = re.sub(r"^\[Source\s*\d+:[^\]]+\]\s*", "", block).strip()
        # Clean JSON markup if any
        if block_clean.startswith("Section:"):
            block_clean = block_clean.replace("Section:", "**Topic:**")
        cleaned_paragraphs.append(block_clean)

    if not cleaned_paragraphs:
        return "No specific answer could be synthesized from the retrieved text."

    # Return clean synthesized points
    result_text = "\n\n".join(cleaned_paragraphs[:3])
    return result_text


def main():
    parser = argparse.ArgumentParser(description="AI-SM: Hybrid RAG Assistant by Suyash Mane")
    parser.add_argument("--data-dir", default=str(PROJECT_ROOT / "data"), help="Path to documents directory")
    parser.add_argument("--query", "-q", type=str, help="Single query to ask")
    parser.add_argument("--top-k", "-k", type=int, default=3, help="Number of chunks to retrieve")
    args = parser.parse_args()

    data_dir = args.data_dir
    print("=" * 70)
    print("  AI-SM: Autonomous RAG & Agent Intelligence")
    print("  Developed by Suyash Mane (suyashmane97@gmail.com)")
    print("=" * 70)

    if not os.path.exists(data_dir):
        print(f"Error: Data directory not found at {data_dir}")
        sys.exit(1)

    print(f"\n[*] Ingesting documents from: {data_dir}")
    engine = HybridRAGEngine(chunk_size=700, chunk_overlap=100)
    total_chunks = engine.load_directory(data_dir)
    print(f"[+] Successfully indexed {total_chunks} chunks across knowledge base.")

    crag = CorrectiveRAG(engine)

    def answer_query(user_q: str):
        print(f"\n[?] Query: {user_q}")
        greeting = check_conversational_intent(user_q)
        if greeting:
            print("\n--- AI-SM Response ---")
            print(greeting)
            print("-" * 70)
            return

        print("[-] Running Hybrid Search (Dense Vector + BM25 RRF)...")
        eval_result = crag.process(user_q, top_k=args.top_k)

        print(f"[-] CRAG Verdict: {eval_result.verdict} (Confidence: {eval_result.confidence_score * 100:.1f}%)")
        print(f"[-] Action: {eval_result.action_taken}")

        print("\n--- Retrieved Sources & Attribution ---")
        for i, chunk in enumerate(eval_result.relevant_chunks, 1):
            print(f"  [{i}] Source: {chunk.source} | RRF Score: {chunk.rrf_score:.4f}")
            snippet = chunk.content.replace("\n", " ")[:140]
            print(f"      Preview: {snippet}...")

        print("\n--- AI-SM Response ---")
        answer = generate_extractive_answer(user_q, eval_result.filtered_context)
        print(answer)
        print("-" * 70)

    if args.query:
        answer_query(args.query)
    else:
        print("\n[!] Entering interactive mode (type 'exit' or 'quit' to end):")
        while True:
            try:
                user_input = input("\nAI-SM > ").strip()
                if not user_input:
                    continue
                if user_input.lower() in ["exit", "quit", "q"]:
                    print("Goodbye from AI-SM!")
                    break
                answer_query(user_input)
            except (KeyboardInterrupt, EOFError):
                print("\nExiting AI-SM.")
                break


if __name__ == "__main__":
    main()

