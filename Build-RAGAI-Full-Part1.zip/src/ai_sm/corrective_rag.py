"""
Corrective RAG (CRAG) & Self-Correction Pipeline
Part of AI-SM Project.
Author: Suyash Mane (suyashmane97@gmail.com)
"""

import re
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from .hybrid_rag import DocumentChunk, HybridRAGEngine


@dataclass
class EvaluationResult:
    """Evaluation result for retrieved context."""
    verdict: str  # "CORRECT", "AMBIGUOUS", "INCORRECT"
    confidence_score: float  # 0.0 to 1.0
    relevant_chunks: List[DocumentChunk]
    filtered_context: str
    action_taken: str


class CorrectiveRAG:
    """
    Evaluates retrieval quality and corrects ambiguous or irrelevant context
    before generation, following Corrective RAG (CRAG) principles.
    """

    def __init__(
        self,
        rag_engine: HybridRAGEngine,
        high_threshold: float = 0.45,
        low_threshold: float = 0.15,
    ):
        self.engine = rag_engine
        self.high_threshold = high_threshold
        self.low_threshold = low_threshold

    def evaluate_chunk_relevance(self, query: str, chunk: DocumentChunk) -> float:
        """
        Heuristic semantic & lexical relevance evaluator between query and chunk.
        Calculates term overlap, query coverage, and density.
        """
        q_terms = set(re.findall(r"\b\w{3,}\b", query.lower()))
        if not q_terms:
            return 0.0

        content_lower = chunk.content.lower()
        chunk_words = re.findall(r"\b\w+\b", content_lower)
        if not chunk_words:
            return 0.0

        # Term coverage (what % of query keywords are in the chunk)
        matched_terms = sum(1 for term in q_terms if term in content_lower)
        coverage_score = matched_terms / len(q_terms)

        # Keyword density
        density = sum(content_lower.count(term) for term in q_terms) / len(chunk_words)
        normalized_density = min(density * 10.0, 1.0)

        # RRF influence
        rrf_boost = min(chunk.rrf_score * 15.0, 0.4)

        relevance = (0.5 * coverage_score) + (0.3 * normalized_density) + (0.2 * rrf_boost)
        return min(relevance, 1.0)

    def filter_strip_irrelevant(self, query: str, chunk: DocumentChunk) -> str:
        """Strips out sentences that bear no relevance to the query."""
        sentences = re.split(r"(?<=[.?!])\s+", chunk.content)
        q_terms = set(re.findall(r"\b\w{3,}\b", query.lower()))
        
        kept = []
        for sent in sentences:
            sent_lower = sent.lower()
            if any(term in sent_lower for term in q_terms):
                kept.append(sent)

        # If too strict and nothing kept, retain first 2 sentences
        if not kept and sentences:
            kept = sentences[:2]

        return " ".join(kept)

    def process(self, query: str, top_k: int = 4) -> EvaluationResult:
        """
        Executes Corrective RAG pipeline:
        1. Retrieves chunks via Hybrid Search.
        2. Evaluates relevance of each chunk.
        3. Triages:
           - High confidence -> CORRECT: Use full context.
           - Medium confidence -> AMBIGUOUS: Strip irrelevant sentences & refine.
           - Low confidence -> INCORRECT: Trigger fallback alert / query expansion.
        """
        retrieved = self.engine.retrieve(query, top_k=top_k)
        if not retrieved:
            return EvaluationResult(
                verdict="INCORRECT",
                confidence_score=0.0,
                relevant_chunks=[],
                filtered_context="",
                action_taken="No documents matched query. Fallback needed.",
            )

        scored_chunks = []
        for c in retrieved:
            score = self.evaluate_chunk_relevance(query, c)
            scored_chunks.append((c, score))

        # Overall confidence is average of top chunks
        avg_score = sum(s for _, s in scored_chunks) / len(scored_chunks)

        if avg_score >= self.high_threshold:
            verdict = "CORRECT"
            relevant = [c for c, s in scored_chunks if s >= self.low_threshold]
            filtered_context = self.engine.format_context(relevant)
            action = "High retrieval confidence. Direct knowledge synthesis enabled."

        elif avg_score >= self.low_threshold:
            verdict = "AMBIGUOUS"
            relevant = []
            filtered_parts = []
            for c, s in scored_chunks:
                if s >= self.low_threshold:
                    cleaned_text = self.filter_strip_irrelevant(query, c)
                    c.content = cleaned_text
                    relevant.append(c)
                    filtered_parts.append(f"[{c.source}] {cleaned_text}")
            filtered_context = "\n\n".join(filtered_parts)
            action = "Ambiguous retrieval confidence. Irrelevant context stripped & focused."

        else:
            verdict = "INCORRECT"
            relevant = [scored_chunks[0][0]] if scored_chunks else []
            filtered_context = ""
            action = "Low retrieval confidence. Query formulation fallback recommended."

        return EvaluationResult(
            verdict=verdict,
            confidence_score=round(avg_score, 3),
            relevant_chunks=relevant,
            filtered_context=filtered_context,
            action_taken=action,
        )

