"""
Hybrid RAG Engine (Dense Semantic + Sparse Keyword Search with Reciprocal Rank Fusion)
Part of AI-SM Project.
Author: Suyash Mane (suyashmane97@gmail.com)
"""

import os
import re
import math
import json
import csv
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field

try:
    import numpy as np
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    np = None


@dataclass
class DocumentChunk:
    """Represents a text chunk with metadata."""
    chunk_id: str
    content: str
    source: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    dense_score: float = 0.0
    sparse_score: float = 0.0
    rrf_score: float = 0.0


class TextSplitter:
    """Splits text recursively preserving semantic boundaries."""

    def __init__(self, chunk_size: int = 800, chunk_overlap: int = 150):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def split_text(self, text: str) -> List[str]:
        if not text or not text.strip():
            return []
        
        # Split separators in priority order
        separators = ["\n\n", "\n", ". ", "? ", "! ", " ", ""]
        return self._split_recursive(text.strip(), separators)

    def _split_recursive(self, text: str, separators: List[str]) -> List[str]:
        if len(text) <= self.chunk_size or not separators:
            return [text.strip()] if text.strip() else []

        sep = separators[0]
        splits = text.split(sep) if sep else list(text)
        
        chunks = []
        current_chunk = ""
        
        for part in splits:
            candidate = current_chunk + (sep if current_chunk else "") + part
            if len(candidate) <= self.chunk_size:
                current_chunk = candidate
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                if len(part) > self.chunk_size and len(separators) > 1:
                    sub_chunks = self._split_recursive(part, separators[1:])
                    chunks.extend(sub_chunks)
                    current_chunk = ""
                else:
                    current_chunk = part
        
        if current_chunk and current_chunk.strip():
            chunks.append(current_chunk.strip())

        # Apply overlap between chunks if possible
        if self.chunk_overlap > 0 and len(chunks) > 1:
            overlapped = []
            for i, ch in enumerate(chunks):
                if i > 0 and len(chunks[i - 1]) > self.chunk_overlap:
                    tail = chunks[i - 1][-self.chunk_overlap:]
                    overlapped.append(tail + " ... " + ch)
                else:
                    overlapped.append(ch)
            return overlapped

        return chunks


class BM25Retriever:
    """Lightweight in-memory BM25 retrieval for sparse keyword search."""

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.corpus: List[List[str]] = []
        self.doc_lengths: List[int] = []
        self.avg_doc_length: float = 0.0
        self.df: Dict[str, int] = {}
        self.idf: Dict[str, float] = {}
        self.doc_count: int = 0

    def _tokenize(self, text: str) -> List[str]:
        return [w.lower() for w in re.findall(r"\b\w+\b", text) if len(w) > 1]

    def fit(self, texts: List[str]):
        self.corpus = [self._tokenize(t) for t in texts]
        self.doc_count = len(self.corpus)
        if self.doc_count == 0:
            return

        self.doc_lengths = [len(doc) for doc in self.corpus]
        self.avg_doc_length = sum(self.doc_lengths) / max(self.doc_count, 1)

        self.df = {}
        for doc in self.corpus:
            unique_words = set(doc)
            for word in unique_words:
                self.df[word] = self.df.get(word, 0) + 1

        self.idf = {}
        for word, freq in self.df.items():
            # Standard Lucene/BM25 IDF formula
            self.idf[word] = math.log(1.0 + (self.doc_count - freq + 0.5) / (freq + 0.5))

    def score(self, query: str) -> List[float]:
        query_tokens = self._tokenize(query)
        scores = [0.0] * self.doc_count

        for q_term in query_tokens:
            if q_term not in self.idf:
                continue
            idf_val = self.idf[q_term]

            for idx, doc in enumerate(self.corpus):
                term_count = doc.count(q_term)
                if term_count == 0:
                    continue
                doc_len = self.doc_lengths[idx]
                numerator = term_count * (self.k1 + 1.0)
                denominator = term_count + self.k1 * (1.0 - self.b + self.b * (doc_len / (self.avg_doc_length or 1.0)))
                scores[idx] += idf_val * (numerator / denominator)

        return scores


class DenseRetriever:
    """Semantic vector retriever using TF-IDF / Cosine similarity or embeddings."""

    def __init__(self):
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), stop_words='english') if SKLEARN_AVAILABLE else None
        self.tfidf_matrix = None
        self.fitted = False

    def fit(self, texts: List[str]):
        if not SKLEARN_AVAILABLE or not texts:
            return
        try:
            self.tfidf_matrix = self.vectorizer.fit_transform(texts)
            self.fitted = True
        except Exception:
            self.fitted = False

    def score(self, query: str) -> List[float]:
        if not self.fitted or not SKLEARN_AVAILABLE:
            return []
        try:
            query_vec = self.vectorizer.transform([query])
            similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
            return similarities.tolist()
        except Exception:
            return []


class HybridRAGEngine:
    """
    AI-SM Hybrid RAG Engine
    Combines dense semantic vector retrieval with sparse keyword BM25 retrieval
    using Reciprocal Rank Fusion (RRF).
    """

    def __init__(
        self,
        chunk_size: int = 700,
        chunk_overlap: int = 100,
        rrf_k: int = 60,
    ):
        self.splitter = TextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        self.rrf_k = rrf_k
        self.bm25 = BM25Retriever()
        self.dense = DenseRetriever()
        self.chunks: List[DocumentChunk] = []

    def load_document(self, file_path: str) -> List[DocumentChunk]:
        """Loads a document file (Markdown, TXT, JSON, CSV) and splits it into chunks."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        ext = os.path.splitext(file_path)[1].lower()
        chunks = []

        if ext in [".md", ".txt"]:
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            raw_chunks = self.splitter.split_text(content)
            for idx, text in enumerate(raw_chunks):
                chunks.append(
                    DocumentChunk(
                        chunk_id=f"{os.path.basename(file_path)}_{idx}",
                        content=text,
                        source=os.path.basename(file_path),
                        metadata={"file_type": ext, "chunk_index": idx},
                    )
                )

        elif ext == ".json":
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                data = json.load(f)
            # Flatten JSON elements into searchable sections
            if isinstance(data, dict):
                for key, val in data.items():
                    val_str = json.dumps(val, indent=2) if isinstance(val, (dict, list)) else str(val)
                    chunks.append(
                        DocumentChunk(
                            chunk_id=f"{os.path.basename(file_path)}_{key}",
                            content=f"Section: {key}\n{val_str}",
                            source=os.path.basename(file_path),
                            metadata={"section": key, "file_type": "json"},
                        )
                    )
            elif isinstance(data, list):
                for idx, item in enumerate(data):
                    chunks.append(
                        DocumentChunk(
                            chunk_id=f"{os.path.basename(file_path)}_{idx}",
                            content=json.dumps(item, indent=2),
                            source=os.path.basename(file_path),
                            metadata={"item_index": idx, "file_type": "json"},
                        )
                    )

        elif ext == ".csv":
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                reader = csv.DictReader(f)
                for idx, row in enumerate(reader):
                    row_content = " | ".join(f"{k}: {v}" for k, v in row.items())
                    chunks.append(
                        DocumentChunk(
                            chunk_id=f"{os.path.basename(file_path)}_row_{idx}",
                            content=row_content,
                            source=os.path.basename(file_path),
                            metadata={"row_index": idx, "file_type": "csv"},
                        )
                    )

        return chunks

    def load_directory(self, dir_path: str) -> int:
        """Loads all supported files in a directory and indexes them."""
        if not os.path.exists(dir_path):
            raise FileNotFoundError(f"Directory not found: {dir_path}")

        loaded_chunks = []
        for root, _, files in os.walk(dir_path):
            for file in files:
                if file.endswith((".md", ".txt", ".json", ".csv")):
                    full_path = os.path.join(root, file)
                    try:
                        doc_chunks = self.load_document(full_path)
                        loaded_chunks.extend(doc_chunks)
                    except Exception as e:
                        print(f"Warning: Failed to load {file}: {e}")

        self.chunks = loaded_chunks
        self._build_indexes()
        return len(self.chunks)

    def _build_indexes(self):
        """Builds both dense and sparse retrieval indexes."""
        if not self.chunks:
            return
        corpus_texts = [c.content for c in self.chunks]
        self.bm25.fit(corpus_texts)
        self.dense.fit(corpus_texts)

    def retrieve(self, query: str, top_k: int = 4) -> List[DocumentChunk]:
        """
        Performs Hybrid Search using Reciprocal Rank Fusion (RRF).
        RRF Score = 1 / (rrf_k + rank_dense) + 1 / (rrf_k + rank_sparse)
        """
        if not self.chunks or not query.strip():
            return []

        # 1. Sparse BM25 Scoring
        bm25_scores = self.bm25.score(query)
        sparse_ranked = sorted(
            range(len(bm25_scores)), key=lambda i: bm25_scores[i], reverse=True
        )

        # 2. Dense Semantic Scoring
        dense_scores = self.dense.score(query)
        if dense_scores and len(dense_scores) == len(self.chunks):
            dense_ranked = sorted(
                range(len(dense_scores)), key=lambda i: dense_scores[i], reverse=True
            )
        else:
            dense_ranked = sparse_ranked

        # 3. Compute Reciprocal Rank Fusion (RRF)
        rrf_scores: Dict[int, float] = {i: 0.0 for i in range(len(self.chunks))}

        for rank, idx in enumerate(sparse_ranked):
            # Only count items with positive score or top rank
            if bm25_scores[idx] > 0 or rank < top_k * 2:
                rrf_scores[idx] += 1.0 / (self.rrf_k + (rank + 1))

        for rank, idx in enumerate(dense_ranked):
            if (dense_scores and dense_scores[idx] > 0) or rank < top_k * 2:
                rrf_scores[idx] += 1.0 / (self.rrf_k + (rank + 1))

        # Sort chunks by final RRF score
        top_indices = sorted(rrf_scores.keys(), key=lambda i: rrf_scores[i], reverse=True)[:top_k]

        results = []
        for idx in top_indices:
            chunk = self.chunks[idx]
            chunk.sparse_score = bm25_scores[idx] if idx < len(bm25_scores) else 0.0
            chunk.dense_score = dense_scores[idx] if dense_scores and idx < len(dense_scores) else 0.0
            chunk.rrf_score = rrf_scores[idx]
            results.append(chunk)

        return results

    def format_context(self, retrieved_chunks: List[DocumentChunk]) -> str:
        """Formats retrieved chunks into clean markdown context for LLM prompt."""
        formatted_blocks = []
        for i, chunk in enumerate(retrieved_chunks, 1):
            source_tag = f"[Source {i}: {chunk.source}]"
            formatted_blocks.append(f"{source_tag}\n{chunk.content}")
        return "\n\n---\n\n".join(formatted_blocks)

