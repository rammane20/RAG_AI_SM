"""
Streamlit Web Application for AI-SM
Author: Suyash Mane (suyashmane97@gmail.com)
Project: AI-SM
"""

import os
import sys
import mimetypes
from pathlib import Path

# Ensure correct MIME type for ES modules on Windows
mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("application/javascript", ".mjs")

import streamlit as st

# Add project root to sys.path
CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.ai_sm.hybrid_rag import HybridRAGEngine
from src.ai_sm.corrective_rag import CorrectiveRAG
from src.ai_sm.cli_app import generate_extractive_answer, check_conversational_intent

# Page Configuration
st.set_page_config(
    page_title="AI-SM | Intelligent RAG Assistant",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom Styling
st.markdown("""
<style>
    .main-title {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1E88E5;
        margin-bottom: 0px;
    }
    .sub-title {
        font-size: 1rem;
        color: #666;
        margin-bottom: 1.5rem;
    }
    .badge-correct {
        background-color: #d4edda;
        color: #155724;
        padding: 4px 8px;
        border-radius: 4px;
        font-weight: 600;
    }
    .badge-ambiguous {
        background-color: #fff3cd;
        color: #856404;
        padding: 4px 8px;
        border-radius: 4px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)

# Title Header
st.markdown('<div class="main-title">🧠 AI-SM: Intelligent RAG Assistant</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-title">Developed by <b>Suyash Mane</b> (suyashmane97@gmail.com) | Powered by Hybrid Search & Corrective RAG</div>', unsafe_allow_html=True)

# Sidebar Configuration
st.sidebar.header("⚙️ Settings & Knowledge Base")
data_path = st.sidebar.text_input("Data Directory", value=str(PROJECT_ROOT / "data"))
top_k = st.sidebar.slider("Top K Documents", min_value=1, max_value=8, value=3)
rrf_k = st.sidebar.slider("RRF Constant (k)", min_value=10, max_value=100, value=60)

# Initialize Engine in Session State
@st.cache_resource(show_spinner="Indexing knowledge base documents...")
def get_rag_engine(path: str, k_val: int):
    engine = HybridRAGEngine(chunk_size=700, chunk_overlap=100, rrf_k=k_val)
    if os.path.exists(path):
        engine.load_directory(path)
    return engine

try:
    engine = get_rag_engine(data_path, rrf_k)
    crag = CorrectiveRAG(engine)
    st.sidebar.success(f"Indexed **{len(engine.chunks)}** chunks from `{os.path.basename(data_path)}`")
    
    # List indexed files
    if os.path.exists(data_path):
        files = [f for f in os.listdir(data_path) if f.endswith((".md", ".txt", ".json", ".csv"))]
        st.sidebar.markdown("### 📁 Indexed Documents")
        for f in files:
            st.sidebar.caption(f"• {f}")
except Exception as e:
    st.sidebar.error(f"Error loading documents: {e}")
    engine = None
    crag = None

# Initialize Chat History
if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! I am AI-SM, your Retrieval-Augmented Generation assistant. Ask me anything about AI agent architectures, vector databases, chunking strategies, or LLM engineering!"}
    ]

# Display Previous Messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if "details" in msg:
            with st.expander("🔍 View Retrieved Sources & CRAG Analysis"):
                st.json(msg["details"])

# Chat Input
if prompt := st.chat_input("Ask a question about the AI-SM knowledge base..."):
    # Append User Message
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Process Assistant Response
    with st.chat_message("assistant"):
        # 1. Check for conversational greetings first
        greeting = check_conversational_intent(prompt)
        if greeting:
            st.markdown(greeting)
            st.session_state.messages.append({
                "role": "assistant",
                "content": greeting,
            })
        elif crag and engine and len(engine.chunks) > 0:
            with st.spinner("Executing Hybrid Search & Corrective Evaluation..."):
                eval_res = crag.process(prompt, top_k=top_k)
                answer = generate_extractive_answer(prompt, eval_res.filtered_context)

                # Format Verdict Badge
                if eval_res.verdict == "CORRECT":
                    st.markdown(f'<span class="badge-correct">✅ MATCH FOUND ({eval_res.confidence_score * 100:.1f}% confidence)</span>', unsafe_allow_html=True)
                elif eval_res.verdict == "AMBIGUOUS":
                    st.markdown(f'<span class="badge-ambiguous">⚠️ PARTIAL MATCH ({eval_res.confidence_score * 100:.1f}% confidence)</span>', unsafe_allow_html=True)
                else:
                    st.markdown('<span class="badge-ambiguous">ℹ️ LOW MATCH CONFIDENCE</span>', unsafe_allow_html=True)

                st.markdown(answer)

                details = {
                    "verdict": eval_res.verdict,
                    "confidence_score": eval_res.confidence_score,
                    "action_taken": eval_res.action_taken,
                    "retrieved_sources": [
                        {
                            "source": c.source,
                            "rrf_score": round(c.rrf_score, 4),
                            "dense_score": round(c.dense_score, 4),
                            "sparse_score": round(c.sparse_score, 4),
                            "snippet": c.content[:200] + "...",
                        }
                        for c in eval_res.relevant_chunks
                    ],
                }

                with st.expander("🔍 View Retrieved Sources & CRAG Analysis"):
                    st.json(details)

                st.session_state.messages.append({
                    "role": "assistant",
                    "content": answer,
                    "details": details,
                })
        else:
            fallback = "Unable to process query: Knowledge base documents are not indexed or directory is missing."
            st.error(fallback)
            st.session_state.messages.append({"role": "assistant", "content": fallback})

