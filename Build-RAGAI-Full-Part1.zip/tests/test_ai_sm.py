"""
Unit and Integration Tests for AI-SM Project
Author: Suyash Mane (suyashmane97@gmail.com)
Project: AI-SM
"""

import os
import sys
import unittest
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.ai_sm.hybrid_rag import HybridRAGEngine, TextSplitter, BM25Retriever
from src.ai_sm.corrective_rag import CorrectiveRAG


class TestAISMSystem(unittest.TestCase):

    def setUp(self):
        self.data_dir = PROJECT_ROOT / "data"
        self.engine = HybridRAGEngine(chunk_size=500, chunk_overlap=80)
        self.crag = CorrectiveRAG(self.engine)

    def test_data_directory_exists_and_contains_files(self):
        """Verify data directory has all required knowledge documents."""
        self.assertTrue(self.data_dir.exists(), "data/ directory must exist")
        files = list(self.data_dir.iterdir())
        self.assertGreaterEqual(len(files), 4, "data/ directory should have at least 4 files")
        
        file_names = [f.name for f in files]
        self.assertIn("ai_agents_architecture.md", file_names)
        self.assertIn("rag_best_practices.json", file_names)
        self.assertIn("vector_databases_overview.csv", file_names)
        self.assertIn("llm_engineering_handbook.txt", file_names)

    def test_text_splitter(self):
        """Test recursive character text splitting."""
        splitter = TextSplitter(chunk_size=100, chunk_overlap=20)
        sample = "Sentence one is here. " * 10
        chunks = splitter.split_text(sample)
        self.assertGreater(len(chunks), 1)
        for c in chunks:
            self.assertLessEqual(len(c), 200)

    def test_bm25_retriever(self):
        """Test sparse BM25 retrieval."""
        retriever = BM25Retriever()
        docs = [
            "ChromaDB is a lightweight embedded vector database for local development.",
            "Pinecone is a cloud managed serverless vector database.",
            "ReAct synergizes reasoning and acting in language model agents.",
        ]
        retriever.fit(docs)
        scores = retriever.score("ChromaDB vector database")
        self.assertGreater(scores[0], scores[1])
        self.assertGreater(scores[0], scores[2])

    def test_hybrid_rag_indexing_and_retrieval(self):
        """Test full Hybrid RAG index and retrieval pipeline."""
        total_chunks = self.engine.load_directory(str(self.data_dir))
        self.assertGreater(total_chunks, 10, "Should index more than 10 chunks")

        # Query 1: Agent Architecture
        results_agent = self.engine.retrieve("What is the ReAct loop?", top_k=3)
        self.assertEqual(len(results_agent), 3)
        self.assertTrue(any("ai_agents_architecture.md" in c.source for c in results_agent))

        # Query 2: Vector DB comparison
        results_db = self.engine.retrieve("Which database uses HNSW indexing?", top_k=3)
        self.assertEqual(len(results_db), 3)
        self.assertTrue(any("vector_databases" in c.source or "rag_best_practices" in c.source for c in results_db))

    def test_corrective_rag(self):
        """Test Corrective RAG evaluation pipeline."""
        self.engine.load_directory(str(self.data_dir))

        # High confidence query
        res_correct = self.crag.process("What are autonomous AI agents and ReAct?", top_k=3)
        self.assertIn(res_correct.verdict, ["CORRECT", "AMBIGUOUS"])
        self.assertGreater(res_correct.confidence_score, 0.1)
        self.assertGreater(len(res_correct.relevant_chunks), 0)

        # Irrelevant query
        res_irrelevant = self.crag.process("xyzqwerty nonexistent quantum cooking recipe", top_k=3)
        self.assertEqual(res_irrelevant.verdict, "INCORRECT")

    def test_no_legacy_author_in_key_files(self):
        """Verify that legacy author names have been cleanly removed."""
        files_to_check = [
            PROJECT_ROOT / "pyproject.toml",
            PROJECT_ROOT / "LICENSE",
            PROJECT_ROOT / "README.md",
            PROJECT_ROOT / "docs" / "README.md",
        ]
        for fpath in files_to_check:
            content = fpath.read_text(encoding="utf-8")
            self.assertNotIn("Daethyra", content, f"Found legacy author in {fpath.name}")
            self.assertNotIn("Carino", content, f"Found legacy author in {fpath.name}")
            self.assertIn("Suyash Mane", content, f"Missing Suyash Mane in {fpath.name}")


if __name__ == "__main__":
    unittest.main()
